SPHINX_SWITCH=False
# change the SPHINS_SWITCH to True when generating the .html pages in the ./docs folder using sphinx.
# when building the html, type "build html" under the docs folder, as shown below:
# ~/pysofi/docs>: make html
