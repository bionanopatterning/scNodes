f = open("shaders/ne_reconstructor_shader.glsl")
